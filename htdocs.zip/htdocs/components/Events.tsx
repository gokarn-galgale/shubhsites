import React from 'react';
import { WeddingEvent }